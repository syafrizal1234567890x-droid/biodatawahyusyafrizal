package com.example.blajarflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
