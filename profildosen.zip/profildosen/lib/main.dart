import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Profil Dosen App',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const DosenListPage(),
    );
  }
}

// ==============================
// HALAMAN 1 — DAFTAR DOSEN
// ==============================
class DosenListPage extends StatelessWidget {
  const DosenListPage({super.key});

  final List<Map<String, String>> dosenList = const [
    {
      'nama': 'Wahyu Syafrizal, S.Kom',
      'jabatan': 'Kaprodi Informatika',
      'email': 'andi.wijaya@kampus.ac.id',
      'foto': 'https://i.pravatar.cc/150?img=1'
    },
    {
      'nama': 'Ir. Rina Marlina, M.T',
      'jabatan': 'Dosen Jaringan Komputer',
      'email': 'rina.marlina@kampus.ac.id',
      'foto': 'https://i.pravatar.cc/150?img=5'
    },
    {
      'nama': 'Drs. Budi Santoso, M.Sc',
      'jabatan': 'Dosen Pemrograman',
      'email': 'budi.santoso@kampus.ac.id',
      'foto': 'https://i.pravatar.cc/150?img=3'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daftar Dosen'),
        centerTitle: true,
      ),
      body: ListView.builder(
        itemCount: dosenList.length,
        itemBuilder: (context, index) {
          final dosen = dosenList[index];
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            elevation: 3,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: ListTile(
              leading: CircleAvatar(
                radius: 28,
                backgroundImage: NetworkImage(dosen['foto']!),
              ),
              title: Text(
                dosen['nama']!,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(dosen['jabatan']!),
              trailing: const Icon(Icons.arrow_forward_ios),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DosenDetailPage(dosen: dosen),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

// ==============================
// HALAMAN 2 — DETAIL DOSEN
// ==============================
class DosenDetailPage extends StatelessWidget {
  final Map<String, String> dosen;

  const DosenDetailPage({super.key, required this.dosen});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(dosen['nama']!),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            CircleAvatar(
              radius: 60,
              backgroundImage: NetworkImage(dosen['foto']!),
            ),
            const SizedBox(height: 20),
            Text(
              dosen['nama']!,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),
            Text(
              dosen['jabatan']!,
              style: const TextStyle(fontSize: 18, color: Colors.grey),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            Card(
              elevation: 3,
              child: ListTile(
                leading: const Icon(Icons.email, color: Colors.indigo),
                title: Text(dosen['email']!),
              ),
            ),
            const Spacer(),
            ElevatedButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.arrow_back),
              label: const Text('Kembali'),
              style: ElevatedButton.styleFrom(
                padding:
                const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
