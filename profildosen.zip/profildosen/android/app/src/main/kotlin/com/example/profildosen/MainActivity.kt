package com.example.profildosen

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
