// ==========================================================
// File: main.dart
// Dibuat oleh: Wahyu Syafrizal
// NIM: 701230195
// Prodi: Sistem Informasi - UIN Sulthan Thaha Saifuddin Jambi
// Tahun Akademik: 2025
// Deskripsi: File utama yang menjalankan aplikasi Flutter
//             "Campus Feedback" dan mengatur tema global.
// ==========================================================

import 'package:flutter/material.dart';
import 'home_page.dart';

void main() {
  runApp(const CampusFeedbackApp());
}

class CampusFeedbackApp extends StatelessWidget {
  const CampusFeedbackApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Campus Feedback',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.blue),
      home: const HomePage(),
    );
  }
}
