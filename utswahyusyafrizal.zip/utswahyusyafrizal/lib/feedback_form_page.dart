// ==========================================================
// File: feedback_form_page.dart
// Redesigned: Ultra Elegant & Premium Design
// Deskripsi: Form feedback dengan desain glassmorphism,
//            animasi subtle, dan aesthetic premium
// ==========================================================
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'model/feedback_item.dart';

class FeedbackFormPage extends StatefulWidget {
  const FeedbackFormPage({super.key});

  @override
  State<FeedbackFormPage> createState() => _FeedbackFormPageState();
}

class _FeedbackFormPageState extends State<FeedbackFormPage> with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  String name = "";
  String nim = "";
  String? faculty;
  List<String> facilities = [];
  double satisfaction = 3;
  String feedbackType = "Saran";
  bool agree = false;
  String note = "";

  final faculties = [
    "Ushuludin & Studi Agama",
    "Adab & Humaniora",
    "Sains & Teknologi",
    "Ekonomi & Bisnis",
    "Tarbiyah & Keguruan",
    "Syariah",
    "Dakwah",
  ];

  final facilityOptions = [
    "Perpustakaan",
    "Kantin",
    "Laboratorium",
    "Wifi",
  ];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Premium Color Palette - Deep Purple & Gold
    const Color primaryPurple = Color(0xFF6B4CE6);
    const Color deepPurple = Color(0xFF4A32B8);
    const Color accentGold = Color(0xFFFFB84D);
    const Color lightPurple = Color(0xFFE8E3FF);
    const Color backgroundColor = Color(0xFFF8F7FF);

    return Scaffold(
      backgroundColor: backgroundColor,
      body: Stack(
        children: [
          // Animated Background Pattern
          Positioned.fill(
            child: CustomPaint(
              painter: BackgroundPatternPainter(),
            ),
          ),

          CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              // Premium Header
              SliverAppBar(
                expandedHeight: 220,
                floating: false,
                pinned: true,
                elevation: 0,
                backgroundColor: Colors.transparent,
                flexibleSpace: FlexibleSpaceBar(
                  centerTitle: false,
                  titlePadding: const EdgeInsets.only(left: 24, bottom: 16),
                  title: Text(
                    "Feedback Hub",
                    style: GoogleFonts.playfairDisplay(
                      fontWeight: FontWeight.w700,
                      fontSize: 24,
                      color: Colors.white,
                      letterSpacing: 0.5,
                    ),
                  ),
                  background: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          deepPurple,
                          primaryPurple,
                          primaryPurple.withOpacity(0.9),
                        ],
                      ),
                    ),
                    child: Stack(
                      children: [
                        // Floating Orbs
                        Positioned(
                          right: -80,
                          top: 40,
                          child: Container(
                            width: 200,
                            height: 200,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: RadialGradient(
                                colors: [
                                  accentGold.withOpacity(0.15),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          left: -60,
                          bottom: 0,
                          child: Container(
                            width: 160,
                            height: 160,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: RadialGradient(
                                colors: [
                                  Colors.white.withOpacity(0.1),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),
                        ),
                        // Decorative Lines
                        Positioned(
                          right: 40,
                          top: 100,
                          child: Container(
                            width: 60,
                            height: 2,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  accentGold,
                                  accentGold.withOpacity(0),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // Main Content
              SliverToBoxAdapter(
                child: FadeTransition(
                  opacity: _fadeAnimation,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
                    child: Column(
                      children: [
                        // Intro Card with Glassmorphism
                        Container(
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                Colors.white.withOpacity(0.9),
                                Colors.white.withOpacity(0.7),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(28),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.5),
                              width: 1.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: primaryPurple.withOpacity(0.08),
                                blurRadius: 30,
                                offset: const Offset(0, 10),
                              ),
                            ],
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 52,
                                height: 52,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [primaryPurple, deepPurple],
                                  ),
                                  borderRadius: BorderRadius.circular(16),
                                  boxShadow: [
                                    BoxShadow(
                                      color: primaryPurple.withOpacity(0.3),
                                      blurRadius: 12,
                                      offset: const Offset(0, 4),
                                    ),
                                  ],
                                ),
                                child: const Icon(
                                  Icons.auto_awesome_rounded,
                                  color: Colors.white,
                                  size: 26,
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Suaramu Penting",
                                      style: GoogleFonts.poppins(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w700,
                                        color: deepPurple,
                                        letterSpacing: -0.5,
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      "Bantu kami menjadi lebih baik",
                                      style: GoogleFonts.poppins(
                                        fontSize: 12,
                                        color: Colors.grey[600],
                                        fontWeight: FontWeight.w400,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 28),

                        // Main Form with Premium Design
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(32),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.04),
                                blurRadius: 40,
                                offset: const Offset(0, 12),
                              ),
                            ],
                          ),
                          child: Form(
                            key: _formKey,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Personal Data Section
                                _buildSection(
                                  title: "Profil Mahasiswa",
                                  icon: Icons.account_circle_outlined,
                                  color: primaryPurple,
                                  child: Column(
                                    children: [
                                      _buildPremiumTextField(
                                        label: "Nama Lengkap",
                                        hint: "Contoh: Wahyu Syafrizal",
                                        icon: Icons.person_outline_rounded,
                                        color: primaryPurple,
                                        validator: (v) => v!.isEmpty ? "Nama wajib diisi" : null,
                                        onSaved: (v) => name = v!,
                                      ),
                                      const SizedBox(height: 16),
                                      _buildPremiumTextField(
                                        label: "Nomor Induk Mahasiswa",
                                        hint: "Contoh: 2110101234",
                                        icon: Icons.badge_outlined,
                                        color: primaryPurple,
                                        keyboardType: TextInputType.number,
                                        validator: (v) => v!.isEmpty ? "NIM wajib diisi" : null,
                                        onSaved: (v) => nim = v!,
                                      ),
                                      const SizedBox(height: 16),
                                      _buildPremiumDropdown(
                                        label: "Fakultas",
                                        icon: Icons.school_outlined,
                                        color: primaryPurple,
                                        items: faculties,
                                        onChanged: (v) => faculty = v,
                                        validator: (v) => v == null ? "Pilih fakultas" : null,
                                      ),
                                    ],
                                  ),
                                ),

                                // Facilities Section
                                _buildSection(
                                  title: "Fasilitas Kampus",
                                  icon: Icons.location_city_outlined,
                                  color: primaryPurple,
                                  child: Wrap(
                                    spacing: 12,
                                    runSpacing: 12,
                                    children: facilityOptions.map((f) {
                                      final isSelected = facilities.contains(f);
                                      IconData facilityIcon = f == "Perpustakaan"
                                          ? Icons.menu_book_rounded
                                          : f == "Kantin"
                                          ? Icons.restaurant_rounded
                                          : f == "Laboratorium"
                                          ? Icons.science_outlined
                                          : Icons.wifi_rounded;

                                      return InkWell(
                                        onTap: () {
                                          setState(() {
                                            isSelected
                                                ? facilities.remove(f)
                                                : facilities.add(f);
                                          });
                                        },
                                        borderRadius: BorderRadius.circular(20),
                                        child: AnimatedContainer(
                                          duration: const Duration(milliseconds: 300),
                                          curve: Curves.easeInOut,
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 20,
                                            vertical: 14,
                                          ),
                                          decoration: BoxDecoration(
                                            gradient: isSelected
                                                ? LinearGradient(
                                              colors: [primaryPurple, deepPurple],
                                            )
                                                : null,
                                            color: isSelected ? null : lightPurple.withOpacity(0.4),
                                            borderRadius: BorderRadius.circular(20),
                                            border: Border.all(
                                              color: isSelected
                                                  ? Colors.transparent
                                                  : Colors.grey[300]!,
                                              width: 1.5,
                                            ),
                                            boxShadow: isSelected
                                                ? [
                                              BoxShadow(
                                                color: primaryPurple.withOpacity(0.3),
                                                blurRadius: 12,
                                                offset: const Offset(0, 4),
                                              ),
                                            ]
                                                : null,
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Icon(
                                                facilityIcon,
                                                size: 20,
                                                color: isSelected
                                                    ? Colors.white
                                                    : primaryPurple,
                                              ),
                                              const SizedBox(width: 8),
                                              Text(
                                                f,
                                                style: GoogleFonts.poppins(
                                                  fontSize: 14,
                                                  fontWeight: isSelected
                                                      ? FontWeight.w600
                                                      : FontWeight.w500,
                                                  color: isSelected
                                                      ? Colors.white
                                                      : deepPurple,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    }).toList(),
                                  ),
                                ),

                                // Satisfaction Section
                                _buildSection(
                                  title: "Rating Kepuasan",
                                  icon: Icons.emoji_emotions_outlined,
                                  color: primaryPurple,
                                  child: Container(
                                    padding: const EdgeInsets.all(24),
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                        colors: [
                                          lightPurple.withOpacity(0.3),
                                          accentGold.withOpacity(0.1),
                                        ],
                                      ),
                                      borderRadius: BorderRadius.circular(24),
                                      border: Border.all(
                                        color: lightPurple,
                                        width: 1.5,
                                      ),
                                    ),
                                    child: Column(
                                      children: [
                                        // Star Display
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: List.generate(5, (index) {
                                            return Padding(
                                              padding: const EdgeInsets.symmetric(horizontal: 6),
                                              child: AnimatedContainer(
                                                duration: const Duration(milliseconds: 300),
                                                child: Icon(
                                                  index < satisfaction
                                                      ? Icons.star_rounded
                                                      : Icons.star_outline_rounded,
                                                  color: index < satisfaction
                                                      ? accentGold
                                                      : Colors.grey[400],
                                                  size: 36,
                                                ),
                                              ),
                                            );
                                          }),
                                        ),
                                        const SizedBox(height: 12),
                                        Text(
                                          _getSatisfactionText(satisfaction),
                                          style: GoogleFonts.poppins(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w600,
                                            color: primaryPurple,
                                          ),
                                        ),
                                        const SizedBox(height: 8),
                                        Text(
                                          "${satisfaction.toInt()} dari 5 bintang",
                                          style: GoogleFonts.poppins(
                                            fontSize: 13,
                                            color: Colors.grey[600],
                                          ),
                                        ),
                                        const SizedBox(height: 16),
                                        SliderTheme(
                                          data: SliderThemeData(
                                            activeTrackColor: accentGold,
                                            inactiveTrackColor: Colors.grey[300],
                                            thumbColor: accentGold,
                                            overlayColor: accentGold.withOpacity(0.2),
                                            thumbShape: const RoundSliderThumbShape(
                                              enabledThumbRadius: 12,
                                            ),
                                            trackHeight: 8,
                                          ),
                                          child: Slider(
                                            value: satisfaction,
                                            min: 1,
                                            max: 5,
                                            divisions: 4,
                                            onChanged: (v) => setState(() => satisfaction = v),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),

                                // Feedback Type Section
                                _buildSection(
                                  title: "Kategori Feedback",
                                  icon: Icons.category_outlined,
                                  color: primaryPurple,
                                  child: Row(
                                    children: [
                                      _buildFeedbackTypeCard(
                                        type: "Saran",
                                        icon: Icons.lightbulb_outline_rounded,
                                        color: Colors.blue,
                                        primaryColor: primaryPurple,
                                      ),
                                      const SizedBox(width: 12),
                                      _buildFeedbackTypeCard(
                                        type: "Keluhan",
                                        icon: Icons.report_problem_outlined,
                                        color: Colors.orange,
                                        primaryColor: primaryPurple,
                                      ),
                                      const SizedBox(width: 12),
                                      _buildFeedbackTypeCard(
                                        type: "Apresiasi",
                                        icon: Icons.favorite_outline_rounded,
                                        color: Colors.pink,
                                        primaryColor: primaryPurple,
                                      ),
                                    ],
                                  ),
                                ),

                                // Notes Section
                                _buildSection(
                                  title: "Pesan Anda",
                                  icon: Icons.edit_note_rounded,
                                  color: primaryPurple,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: lightPurple.withOpacity(0.2),
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(
                                        color: lightPurple,
                                        width: 1.5,
                                      ),
                                    ),
                                    child: TextFormField(
                                      decoration: InputDecoration(
                                        hintText: "Ceritakan pengalaman, saran, atau apresiasi Anda di sini...",
                                        hintStyle: GoogleFonts.poppins(
                                          color: Colors.grey[400],
                                          fontSize: 14,
                                        ),
                                        border: InputBorder.none,
                                        contentPadding: const EdgeInsets.all(20),
                                      ),
                                      style: GoogleFonts.poppins(
                                        fontSize: 14,
                                        height: 1.6,
                                      ),
                                      minLines: 5,
                                      maxLines: 10,
                                      onSaved: (v) => note = v ?? "",
                                    ),
                                  ),
                                ),

                                // Agreement Section
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
                                  child: InkWell(
                                    onTap: () => setState(() => agree = !agree),
                                    borderRadius: BorderRadius.circular(20),
                                    child: AnimatedContainer(
                                      duration: const Duration(milliseconds: 300),
                                      padding: const EdgeInsets.all(20),
                                      decoration: BoxDecoration(
                                        gradient: agree
                                            ? LinearGradient(
                                          colors: [
                                            lightPurple.withOpacity(0.5),
                                            accentGold.withOpacity(0.2),
                                          ],
                                        )
                                            : null,
                                        color: agree ? null : Colors.grey[50],
                                        borderRadius: BorderRadius.circular(20),
                                        border: Border.all(
                                          color: agree ? primaryPurple : Colors.grey[300]!,
                                          width: 2,
                                        ),
                                      ),
                                      child: Row(
                                        children: [
                                          AnimatedContainer(
                                            duration: const Duration(milliseconds: 300),
                                            width: 28,
                                            height: 28,
                                            decoration: BoxDecoration(
                                              gradient: agree
                                                  ? LinearGradient(
                                                colors: [primaryPurple, deepPurple],
                                              )
                                                  : null,
                                              color: agree ? null : Colors.grey[300],
                                              borderRadius: BorderRadius.circular(8),
                                            ),
                                            child: Icon(
                                              Icons.check_rounded,
                                              color: Colors.white,
                                              size: 18,
                                            ),
                                          ),
                                          const SizedBox(width: 16),
                                          Expanded(
                                            child: Text(
                                              "Saya menyetujui syarat dan ketentuan yang berlaku",
                                              style: GoogleFonts.poppins(
                                                fontSize: 13,
                                                fontWeight: agree ? FontWeight.w600 : FontWeight.w500,
                                                color: agree ? deepPurple : Colors.grey[700],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),

                                // Submit Button
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(24, 0, 24, 32),
                                  child: Container(
                                    width: double.infinity,
                                    height: 60,
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [primaryPurple, deepPurple],
                                      ),
                                      borderRadius: BorderRadius.circular(20),
                                      boxShadow: [
                                        BoxShadow(
                                          color: primaryPurple.withOpacity(0.4),
                                          blurRadius: 20,
                                          offset: const Offset(0, 8),
                                        ),
                                      ],
                                    ),
                                    child: Material(
                                      color: Colors.transparent,
                                      child: InkWell(
                                        borderRadius: BorderRadius.circular(20),
                                        onTap: _handleSubmit,
                                        child: Center(
                                          child: Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              const Icon(
                                                Icons.send_rounded,
                                                color: Colors.white,
                                                size: 22,
                                              ),
                                              const SizedBox(width: 12),
                                              Text(
                                                "Kirim Feedback",
                                                style: GoogleFonts.poppins(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w600,
                                                  color: Colors.white,
                                                  letterSpacing: 0.5,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSection({
    required String title,
    required IconData icon,
    required Color color,
    required Widget child,
  }) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 28, 24, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: color, size: 20),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: GoogleFonts.poppins(
                  fontSize: 17,
                  fontWeight: FontWeight.w700,
                  color: const Color(0xFF4A32B8),
                  letterSpacing: -0.3,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          child,
        ],
      ),
    );
  }

  Widget _buildPremiumTextField({
    required String label,
    required String hint,
    required IconData icon,
    required Color color,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
    void Function(String?)? onSaved,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFF8F7FF),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: Colors.grey[200]!,
          width: 1.5,
        ),
      ),
      child: TextFormField(
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          labelStyle: GoogleFonts.poppins(
            color: color,
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
          hintStyle: GoogleFonts.poppins(
            color: Colors.grey[400],
            fontSize: 13,
          ),
          prefixIcon: Icon(icon, color: color, size: 22),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 20,
            vertical: 18,
          ),
        ),
        style: GoogleFonts.poppins(fontSize: 14),
        keyboardType: keyboardType,
        validator: validator,
        onSaved: onSaved,
      ),
    );
  }

  Widget _buildPremiumDropdown({
    required String label,
    required IconData icon,
    required Color color,
    required List<String> items,
    required void Function(String?) onChanged,
    String? Function(String?)? validator,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFF8F7FF),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: Colors.grey[200]!,
          width: 1.5,
        ),
      ),
      child: DropdownButtonFormField<String>(
        decoration: InputDecoration(
          labelText: label,
          labelStyle: GoogleFonts.poppins(
            color: color,
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
          prefixIcon: Icon(icon, color: color, size: 22),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 20,
            vertical: 18,
          ),
        ),
        style: GoogleFonts.poppins(fontSize: 14, color: Colors.black87),
        dropdownColor: Colors.white,
        items: items.map((item) {
          return DropdownMenuItem(
            value: item,
            child: Text(item, style: GoogleFonts.poppins(fontSize: 14)),
          );
        }).toList(),
        onChanged: onChanged,
        validator: validator,
      ),
    );
  }

  Widget _buildFeedbackTypeCard({
    required String type,
    required IconData icon,
    required Color color,
    required Color primaryColor,
  }) {
    final isSelected = feedbackType == type;

    return Expanded(
      child: InkWell(
        onTap: () => setState(() => feedbackType = type),
        borderRadius: BorderRadius.circular(20),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          padding: const EdgeInsets.symmetric(vertical: 20),
          decoration: BoxDecoration(
            gradient: isSelected
                ? LinearGradient(
              colors: [primaryColor, const Color(0xFF4A32B8)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            )
                : null,
            color: isSelected ? null : const Color(0xFFF8F7FF),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: isSelected ? Colors.transparent : Colors.grey[200]!,
              width: 1.5,
            ),
            boxShadow: isSelected
                ? [
              BoxShadow(
                color: primaryColor.withOpacity(0.3),
                blurRadius: 15,
                offset: const Offset(0, 6),
              ),
            ]
                : null,
          ),
          child: Column(
            children: [
              Icon(
                icon,
                color: isSelected ? Colors.white : color,
                size: 32,
              ),
              const SizedBox(height: 10),
              Text(
                type,
                style: GoogleFonts.poppins(
                  fontSize: 13,
                  fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                  color: isSelected ? Colors.white : Colors.grey[700],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _getSatisfactionText(double rating) {
    if (rating >= 4.5) return "Sangat Puas! 😍";
    if (rating >= 3.5) return "Puas 😊";
    if (rating >= 2.5) return "Cukup 😐";
    if (rating >= 1.5) return "Kurang Puas 😕";
    return "Tidak Puas 😞";
  }

  void _handleSubmit() {
    if (!_formKey.currentState!.validate()) return;
    _formKey.currentState!.save();

    if (!agree) {
      _showAgreementDialog();
      return;
    }

    final item = FeedbackItem(
      name: name,
      nim: nim,
      faculty: faculty!,
      facilities: facilities,
      satisfaction: satisfaction,
      feedbackType: feedbackType,
      agree: agree,
      notes: note,
    );

    // Show success animation
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(
                Icons.check_circle_rounded,
                color: Colors.white,
                size: 24,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    "Berhasil Terkirim!",
                    style: GoogleFonts.poppins(
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    "Terima kasih atas feedback Anda",
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      color: Colors.white.withOpacity(0.9),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: const Color(0xFF6B4CE6),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        margin: const EdgeInsets.all(20),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        duration: const Duration(seconds: 3),
        elevation: 8,
      ),
    );

    Navigator.pop(context, item);
  }

  void _showAgreementDialog() {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
        ),
        child: Container(
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.white,
                const Color(0xFFF8F7FF),
              ],
            ),
            borderRadius: BorderRadius.circular(28),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.orange.shade400,
                      Colors.deepOrange.shade400,
                    ],
                  ),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Icon(
                  Icons.info_outline_rounded,
                  color: Colors.white,
                  size: 40,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                "Persetujuan Diperlukan",
                style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: const Color(0xFF4A32B8),
                ),
              ),
              const SizedBox(height: 12),
              Text(
                "Mohon setujui syarat dan ketentuan terlebih dahulu untuk melanjutkan pengiriman feedback.",
                textAlign: TextAlign.center,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  color: Colors.grey[600],
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 24),
              Container(
                width: double.infinity,
                height: 50,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      const Color(0xFF6B4CE6),
                      const Color(0xFF4A32B8),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF6B4CE6).withOpacity(0.3),
                      blurRadius: 12,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () => Navigator.pop(context),
                    child: Center(
                      child: Text(
                        "Mengerti",
                        style: GoogleFonts.poppins(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Custom Painter for Background Pattern
class BackgroundPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF6B4CE6).withOpacity(0.03)
      ..style = PaintingStyle.fill;

    // Draw subtle circles pattern
    for (var i = 0; i < 5; i++) {
      for (var j = 0; j < 5; j++) {
        canvas.drawCircle(
          Offset(i * size.width / 4, j * size.height / 4),
          40,
          paint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}