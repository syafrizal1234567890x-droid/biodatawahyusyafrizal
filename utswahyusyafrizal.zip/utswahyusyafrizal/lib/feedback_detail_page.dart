// ==========================================================
// Dibuat oleh: Wahyu Syafrizal
// NIM: 701230195
// Prodi: Sistem Informasi - UIN STS Jambi
// Mata Kuliah: Pemrograman Mobile
// Tahun Akademik: 2025
// ==========================================================
//
// Deskripsi:
// File ini berfungsi untuk menampilkan detail lengkap feedback
// mahasiswa yang dipilih dari daftar. Halaman ini juga memiliki
// tombol untuk kembali ke daftar feedback atau menghapus feedback.
//
// Fitur:
// - Menampilkan semua data mahasiswa dari feedback yang dikirim
// - Tombol "Kembali" untuk kembali ke daftar
// - Tombol "Hapus" dengan dialog konfirmasi sebelum menghapus
// - Design modern dengan gradient merah yang elegan
// ==========================================================

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'model/feedback_item.dart';

class FeedbackDetailPage extends StatelessWidget {
  final FeedbackItem feedbackItem;
  const FeedbackDetailPage({super.key, required this.feedbackItem});

  @override
  Widget build(BuildContext context) {
    // Warna berdasarkan tipe feedback
    Color primaryColor;
    Color secondaryColor;
    IconData headerIcon;

    switch (feedbackItem.feedbackType) {
      case "Apresiasi":
        primaryColor = const Color(0xFFE53935); // Red
        secondaryColor = const Color(0xFFEF5350);
        headerIcon = Icons.thumb_up_rounded;
        break;
      case "Keluhan":
        primaryColor = const Color(0xFFC62828); // Dark Red
        secondaryColor = const Color(0xFFE53935);
        headerIcon = Icons.report_problem_rounded;
        break;
      default:
        primaryColor = const Color(0xFFD32F2F); // Medium Red
        secondaryColor = const Color(0xFFEF5350);
        headerIcon = Icons.lightbulb_rounded;
    }

    return Scaffold(
      backgroundColor: Colors.grey[50],
      body: CustomScrollView(
        slivers: [
          // 🎨 AppBar dengan Gradient
          SliverAppBar(
            expandedHeight: 200,
            pinned: true,
            elevation: 0,
            backgroundColor: primaryColor,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [primaryColor, secondaryColor],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(height: 40),
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.2),
                            blurRadius: 15,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                      child: Icon(
                        headerIcon,
                        color: Colors.white,
                        size: 50,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      feedbackItem.feedbackType,
                      style: GoogleFonts.poppins(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // 📝 Content
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // 👤 Info Mahasiswa Card
                  _buildSectionCard(
                    title: "Informasi Mahasiswa",
                    icon: Icons.person_rounded,
                    color: primaryColor,
                    child: Column(
                      children: [
                        _buildInfoRow(
                          Icons.account_circle,
                          "Nama",
                          feedbackItem.name,
                          primaryColor,
                        ),
                        const Divider(height: 20),
                        _buildInfoRow(
                          Icons.badge_rounded,
                          "NIM",
                          feedbackItem.nim,
                          primaryColor,
                        ),
                        const Divider(height: 20),
                        _buildInfoRow(
                          Icons.school_rounded,
                          "Fakultas",
                          feedbackItem.faculty,
                          primaryColor,
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  // 🏢 Fasilitas Card
                  _buildSectionCard(
                    title: "Fasilitas yang Dinilai",
                    icon: Icons.apartment_rounded,
                    color: primaryColor,
                    child: Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: feedbackItem.facilities.map((facility) {
                        return Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                primaryColor.withOpacity(0.1),
                                secondaryColor.withOpacity(0.1),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: primaryColor.withOpacity(0.3),
                              width: 1.5,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.check_circle,
                                size: 16,
                                color: primaryColor,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                facility,
                                style: GoogleFonts.poppins(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: primaryColor,
                                ),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // ⭐ Rating & Status Card
                  _buildSectionCard(
                    title: "Penilaian & Status",
                    icon: Icons.star_rounded,
                    color: primaryColor,
                    child: Column(
                      children: [
                        // Rating
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                primaryColor.withOpacity(0.1),
                                secondaryColor.withOpacity(0.05),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.sentiment_satisfied_rounded,
                                  color: primaryColor, size: 28),
                              const SizedBox(width: 12),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Tingkat Kepuasan",
                                    style: GoogleFonts.poppins(
                                      fontSize: 12,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      ...List.generate(5, (index) {
                                        return Icon(
                                          index < feedbackItem.satisfaction.toInt()
                                              ? Icons.star_rounded
                                              : Icons.star_border_rounded,
                                          color: Colors.amber[700],
                                          size: 20,
                                        );
                                      }),
                                      const SizedBox(width: 8),
                                      Text(
                                        "${feedbackItem.satisfaction.toInt()}/5",
                                        style: GoogleFonts.poppins(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: primaryColor,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        // Persetujuan
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: feedbackItem.agree
                                ? Colors.green[50]
                                : Colors.orange[50],
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: feedbackItem.agree
                                  ? Colors.green[300]!
                                  : Colors.orange[300]!,
                              width: 1.5,
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                feedbackItem.agree
                                    ? Icons.check_circle_rounded
                                    : Icons.cancel_rounded,
                                color: feedbackItem.agree
                                    ? Colors.green[700]
                                    : Colors.orange[700],
                                size: 24,
                              ),
                              const SizedBox(width: 12),
                              Text(
                                feedbackItem.agree
                                    ? "Menyetujui kebijakan feedback"
                                    : "Tidak menyetujui kebijakan",
                                style: GoogleFonts.poppins(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: feedbackItem.agree
                                      ? Colors.green[700]
                                      : Colors.orange[700],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  // 📝 Catatan Card
                  _buildSectionCard(
                    title: "Catatan & Pesan",
                    icon: Icons.message_rounded,
                    color: primaryColor,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.grey[50],
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.grey[200]!),
                      ),
                      child: Text(
                        feedbackItem.notes?.isNotEmpty == true
                            ? feedbackItem.notes!
                            : "Tidak ada catatan tambahan dari pengguna.",
                        style: GoogleFonts.poppins(
                          color: Colors.grey[700],
                          height: 1.6,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 30),

                  // 🎯 Action Buttons
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          icon: const Icon(Icons.arrow_back_rounded),
                          label: Text(
                            "Kembali",
                            style: GoogleFonts.poppins(
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          style: OutlinedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            side: BorderSide(color: primaryColor, width: 2),
                            foregroundColor: primaryColor,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [primaryColor, secondaryColor],
                            ),
                            borderRadius: BorderRadius.circular(12),
                            boxShadow: [
                              BoxShadow(
                                color: primaryColor.withOpacity(0.4),
                                blurRadius: 8,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: ElevatedButton.icon(
                            icon: const Icon(Icons.delete_outline_rounded),
                            label: Text(
                              "Hapus",
                              style: GoogleFonts.poppins(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              foregroundColor: Colors.white,
                              shadowColor: Colors.transparent,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            onPressed: () => _showDeleteDialog(context, primaryColor),
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionCard({
    required String title,
    required IconData icon,
    required Color color,
    required Widget child,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  color.withOpacity(0.1),
                  color.withOpacity(0.05),
                ],
              ),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, color: color, size: 20),
                ),
                const SizedBox(width: 12),
                Text(
                  title,
                  style: GoogleFonts.poppins(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: child,
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value, Color color) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, color: color, size: 20),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: GoogleFonts.poppins(
                  fontSize: 12,
                  color: Colors.grey[600],
                ),
              ),
              const SizedBox(height: 2),
              Text(
                value,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colors.grey[800],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  void _showDeleteDialog(BuildContext context, Color primaryColor) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: primaryColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(Icons.warning_rounded, color: primaryColor, size: 24),
            ),
            const SizedBox(width: 12),
            Text(
              "Konfirmasi Hapus",
              style: GoogleFonts.poppins(
                fontWeight: FontWeight.bold,
                fontSize: 18,
              ),
            ),
          ],
        ),
        content: Text(
          "Apakah Anda yakin ingin menghapus feedback ini? Tindakan ini tidak dapat dibatalkan.",
          style: GoogleFonts.poppins(
            fontSize: 14,
            color: Colors.grey[700],
            height: 1.5,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
            ),
            child: Text(
              "Batal",
              style: GoogleFonts.poppins(
                color: Colors.grey[700],
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryColor, primaryColor.withOpacity(0.8)],
              ),
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pop(context, true);
              },
              style: TextButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                foregroundColor: Colors.white,
              ),
              child: Text(
                "Hapus",
                style: GoogleFonts.poppins(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}