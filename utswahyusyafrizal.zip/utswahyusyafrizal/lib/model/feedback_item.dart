// ==========================================================
// Dibuat oleh: Wahyu Syafrizal
// NIM: 701230195
// Prodi: Sistem Informasi - UIN STS Jambi
// Mata Kuliah: Pemrograman Mobile
// Tahun Akademik: 2025
// ==========================================================
class FeedbackItem {
  final String name;
  final String nim;
  final String faculty;
  final List<String> facilities;
  final double satisfaction;
  final String feedbackType;
  final bool agree;
  final String? notes;

  FeedbackItem({
    required this.name,
    required this.nim,
    required this.faculty,
    required this.facilities,
    required this.satisfaction,
    required this.feedbackType,
    required this.agree,
    this.notes,
  });
}
