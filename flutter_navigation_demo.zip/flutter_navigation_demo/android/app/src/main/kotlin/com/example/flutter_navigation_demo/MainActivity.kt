package com.example.flutter_navigation_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
